
export const NATS_SERVER = "nats.socialcap.dev:4222";
